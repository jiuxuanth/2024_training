package com.jiuth.sysmonitor.dubbo.api;

public interface DemoService {

    String sayHello(String name);

}
