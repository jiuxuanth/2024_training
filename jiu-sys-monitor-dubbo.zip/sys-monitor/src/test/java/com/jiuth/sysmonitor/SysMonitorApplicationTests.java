package com.jiuth.sysmonitor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SysMonitorApplicationTests {

    @Test
    void contextLoads() {
    }

}
